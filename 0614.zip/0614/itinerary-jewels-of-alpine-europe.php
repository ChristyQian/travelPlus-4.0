<!DOCTYPE html>
<html>
	<?php 
	$pageName="itinerary-jewels-of-alpine-europe";
	$tagTitle="行程 - EF TravelPlus | 英孚旅游+";
	$metaTitle="欧洲旅游新选择_EF英孚旅游_一站式旅游专家";
	$metaKeywords="欧洲旅游，EF英孚旅游，EFTravelPlus，品质跟团游，EF英孚教育，告别走马观花，体验式旅行";
	$metaDescription="英孚旅游+,是英孚旗下一站式旅游服务专家，在全球众多国家拥有专业的旅游执行团队和完善的网络体系，用有趣的方式，让你和有趣的年轻人一起，发现未知的精彩世界。";

	$itineraryName="阿尔卑斯山环游之旅";
	$itineraryPrice="￥23,400";

    include_once("itinerary-head.php"); 
?>

	<body data-spy="scroll" data-target="#travelPlusNav">
		<?php include_once('fix-cta.php') ;?>
		<?php include_once('common-header.php');?>
		<!-- Image -->
		<div class="imagesWrap" style="background:url(img/itinerary/billboard/Jewels-of-Alpine-Europe.jpg)  center center no-repeat; background-size:cover;">
			<div class="site">
				<div class="tourInfo">
					<div class="transparentBg"></div>
					<div class="transparentTxt">
						<div class="yellowTxt">国庆档</div>
						<div class="tourName">阿尔卑斯山环游之旅</div>
						<div class="flex-row-start-between">
							<div class="rate">
								<i class="fa fa-star active" aria-hidden="true"></i>
								<i class="fa fa-star active" aria-hidden="true"></i>
								<i class="fa fa-star active" aria-hidden="true"></i>
								<i class="fa fa-star active" aria-hidden="true"></i>
								<i class="fa fa-star active" aria-hidden="true"></i>
							</div>
							<div class="pinkTxt">仅剩5席</div>
						</div>
					</div>
				</div>
				<div class="discount">
					<div class="transparentBg"></div>
					<div class="transparentTxt">
						<p>国庆出发</p>
						仅剩5席
					</div>
				</div>
			</div>
		</div>
		<!-- Itinerary Info -->
		<div class="site">
			<div class="itineraryInfo">
				<div class="flex-row-start-around itineraryBasicInfo">
					<div class="flex1 itineraryLine">
						<div class="days">13天</div>
						<div class="flex-row-start-between">
							<div>瑞士</div>
							<i class="grayArrow"></i>
							<div>法国</div>
							<i class="grayArrow"></i>
							<div>意大利</div>
							<i class="grayArrow"></i>
							<div>奥地利</div>
							<i class="grayArrow"></i>
							<div>德国</div>
							<i class="grayArrow"></i>
						</div>
					</div>
					<div class="flex1 flex-row-start-between">
						<div class="priceWG">
							￥23,400
							<span>起</span>
						</div>
						<div>
							<a class="blueRBtn" href="#getPersonalizedPrice">获取实时价格</a>
						</div>
					</div>
				</div>
				<div class="flex-row-start-around itineraryHighLights">
					<div class="flex1 tourGuide">
						<p class="serif">加入我们吧，一起从瑞士卢塞恩湖游历到法国安纳西，前往风景如画的峡谷，沿科莫湖闲庭信步，穿过列车敦士登一路直达冬季仙境因斯布鲁克和巴伐利亚首府慕尼黑。</p>
						<div class="com_profile">
							<div class="imgWrap">
								<img src="img/itinerary/tourDirector/Fortuna-Gallo.jpg" />
							</div>
							<div class="userInfo">
								<span class="position">外籍导游</span>
								<span class="name">Fortuna Gallo</span>
							</div>
						</div>
					</div>
					<div class="flex1 hightLight">
						<h4>行程亮点</h4>
						<p>
							壮丽的高山美景<br/> 瑞士巧克力、法式糕点和德国啤酒
							<br/> 美丽的阿尔卑斯山湖畔村庄景致
							<br/> 圣莫里茨的冬季仙境
							<br/> 因斯布鲁克的神来之笔
							<br/> 感受巴伐利亚州的美食与文化
							<br/>
						</p>
					</div>
				</div>
			</div>
		</div>
		<!-- Swiper -->
		<div class="site itineraryPhoto">
			<div class="swiper-container">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/itinerary/jewels-of-alpine-europe-1.jpg" />
							</div>
							<div class="bgIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">梵蒂冈不可思议的建筑</div>
							</div>
						</div>
						<div class="photoBy">
							<div class="com_profile">
								<div class="imgWrap">
									<img src="img/itinerary/tourDirector/Gattazzo.jpg" />
								</div>
							</div>
							Photo by Anita
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/itinerary/jewels-of-alpine-europe-2.jpg" />
							</div>
							<div class="bgIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">梵蒂冈不可思议的建筑</div>
							</div>
						</div>
						<div class="photoBy">
							<div class="com_profile">
								<div class="imgWrap">
									<img src="img/itinerary/tourDirector/Gattazzo.jpg" />
								</div>
							</div>
							Photo by Anita
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/itinerary/jewels-of-alpine-europe-3.jpg" />
							</div>
							<div class="bgIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">梵蒂冈不可思议的建筑</div>
							</div>
						</div>
						<div class="photoBy">
							<div class="com_profile">
								<div class="imgWrap">
									<img src="img/itinerary/tourDirector/Gattazzo.jpg" />
								</div>
							</div>
							Photo by Anita
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/itinerary/jewels-of-alpine-europe-6.jpg" />
							</div>
							<div class="bgIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">梵蒂冈不可思议的建筑</div>
							</div>
						</div>
						<div class="photoBy">
							<div class="com_profile">
								<div class="imgWrap">
									<img src="img/itinerary/tourDirector/Gattazzo.jpg" />
								</div>
							</div>
							Photo by Anita
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/itinerary/jewels-of-alpine-europe-7.jpg" />
							</div>
							<div class="bgIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">梵蒂冈不可思议的建筑</div>
							</div>
						</div>
						<div class="photoBy">
							<div class="com_profile">
								<div class="imgWrap">
									<img src="img/itinerary/tourDirector/Gattazzo.jpg" />
								</div>
							</div>
							Photo by Anita
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/itinerary/jewels-of-alpine-europe-8.jpg" />
							</div>
							<div class="bgIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">梵蒂冈不可思议的建筑</div>
							</div>
						</div>
						<div class="photoBy">
							<div class="com_profile">
								<div class="imgWrap">
									<img src="img/itinerary/tourDirector/Gattazzo.jpg" />
								</div>
							</div>
							Photo by Anita
						</div>
					</div>
				</div>
				<!--<div class="swiper-button-prev"></div>
    				<div class="swiper-button-next"></div>-->
				<!-- 如果需要分页器 -->
				<div class="swiper-pagination">
				</div>
			</div>
		</div>
		<!-- Include -->
		<div class="section blueBg">
			<div class="site">
				<h4>价格包含</h4>
				<div class="includedItems flex-row-start-start section">
					<div class="">
						<div class="imgWrap">
							<img src="img/page-1.svg" />
						</div>
						来往机票
					</div>
					<div class="">
						<div class="imgWrap">
							<img src="img/page-2.svg" />
						</div>
						11晚精选酒店住宿
					</div>
					<div class="">
						<div class="imgWrap">
							<img src="img/page-3.svg" />
						</div>
						每日早餐
					</div>
					<div class="">
						<div class="imgWrap">
							<img src="img/page-4.svg" />
						</div>
						5顿三道式晚餐，供应啤酒或葡萄酒
					</div>
					<div class="">
						<div class="imgWrap">
							<img src="img/page-5.svg" />
						</div>
						多语言外籍导游和中方领队
					</div>
					<div class="">
						<div class="imgWrap">
							<img src="img/page-6.svg" />
						</div>
						专用豪华大巴接送
					</div>
					<div class="">
						<div class="imgWrap">
							<img src="img/page-7.svg" />
						</div>
						陪同观光和精选景点门票
					</div>
					<div class="">
						<div class="imgWrap">
							<img src="img/page-8.svg" />
						</div>
						除自由时间外涉及的海外服务小费
					</div>
					<div class="">
						<div class="imgWrap">
							<img src="img/page-9.svg" />
						</div>
						旅行期间的保险
					</div>
				</div>
			</div>
		</div>
		<!-- Itinerary -->
		<div class="site">
			<h4>行程安排</h4>
			<div class="itineraryIntro section">
				<div class="initialScreenLinear"></div>
				<div class="itineraryMap">
					<img src="img/itinerary/map/jewels-of-alpine-europe.jpg" />
				</div>
				<div class="initialScreen">
					<div class="com_itinerary_summary">
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第1天</label><span>出发</span>
							</div>
							<div class="itinerary_daily_detail">
								<ul>
									<li>启程并抵达苏黎世</li>
								</ul>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第2天</label><span>卢塞恩观光游</span>
							</div>
							<div class="itinerary_daily_detail">
								<ul>
									<li>探索卢塞恩的老城区</li>
									<li>观看狮子雕像</li>
									<li>漫步卡佩尔桥</li>
									<li>在欢迎晚宴上与同行伙伴见面</li>
								</ul>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第3天</label><span>取道伯尔尼前往安纳西</span>
							</div>
							<div class="itinerary_daily_detail">
								<ul>
									<li>欣赏阿尔卑斯山美景</li>
									<li>途经伯尔尼老城，步行经过哥特式大教堂</li>
									<li>途经洛桑和日内瓦湖的葡萄园，前往安纳西</li>
								</ul>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第4天</label><span>安纳西观光游</span>
							</div>
							<div class="itinerary_daily_detail">
								<ul>
									<li>步行经过安纳西老城</li>
									<li>饱览阿尔卑斯山美景</li>
									<li>坐游轮欣赏安纳西湖两岸的庄园</li>
								</ul>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第5天</label><span>取道霞慕尼前往科莫湖地区</span>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第6天</label><span>科莫湖和卡洛塔庄园</span>
							</div>
							<div class="itinerary_daily_detail">
								<ul>
									<li>参观胜利门</li>
									<li>漫步走过卡洛塔庄园的优雅花园</li>
									<li>晚上在科莫湖地区自由活动</li>
								</ul>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第7天</label><span>前往圣莫里茨</span>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第8天</label><span>因斯布鲁克观光之旅</span>
							</div>
							<div class="itinerary_daily_detail">
								<ul>
									<li>参观瓦杜兹，途经王室的山顶城堡</li>
									<li>抵达因斯布鲁克</li>
									<li>观赏黄金屋顶和城市塔</li>
									<li>经过霍夫堡，走进皇宫的鹅卵石庭院</li>
									<li>参观圣詹姆斯大教堂</li>
								</ul>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第9天</label><span>因斯布鲁克自由行</span>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第10天</label><span>慕尼黑自由行</span>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第11天</label><span>慕尼黑观光之旅</span>
							</div>
							<div class="itinerary_daily_detail">
								<ul>
									<li>途经英国花园和时尚的施瓦宾格区</li>
									<li>参观宁芬堡宫的主教宫</li>
									<li>途经音乐厅广场、宫廷花园，进入伯爵宫参观</li>
									<li>游览慕尼黑的中世纪心脏地带玛利亚广场，参观著名的钟琴</li>
									<li>下午在慕尼黑自由活动</li>
									<li>在告别晚宴上和同行伙伴告别</li>
								</ul>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第12天</label><span>返程</span>
							</div>
							<div class="itinerary_daily_detail">
								<ul>
									<li>前往机场搭乘返程航班</li>
								</ul>
							</div>
						</div>
						<div class="itinerary_daily_item">
							<div class="itinerary_daily_title">
								<div class="itemCircle"></div>
								<label>第13天</label><span>抵达中国</span>
							</div>
						</div>
						<p>请注意，以上为示范行程，行程内容可能会因出发日期、航班时间或其他因素发生变动，详情请拨打电话 400-180-7518 查询。</p>
					</div>
				</div>
			</div>
			<button class="borderBtn allItinerary">全部行程</button>
		</div>

		<!-- Hotels -->
		<div class="site hotels">
			<h4>精选酒店</h4>
			<p class="notes">以下是我们的备选酒店，入住视具体情况而定。</p>
			<div class="swiper-container">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/hotel/Ameron Hotel Flora/Ameron Hotel Flora_dining.jpg" />
							</div>
							<div class="hotelIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">Ameron Hotel Flora弗洛拉卢塞恩亚美隆酒店</div>
							</div>
						</div>
						<div class="hotelDes">坐落于卢塞恩市中心，可以步行到达所有景点，餐厅和购物地点。 离火车站只有5分钟步行距离。</div>
					</div>
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/hotel/Ameron Hotel Flora/Ameron Hotel Flora_room.jpg" />
							</div>
							<div class="hotelIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">Ameron Hotel Flora弗洛拉卢塞恩亚美隆酒店</div>
							</div>
						</div>
						<div class="hotelDes">酒店附近的景点有：卢塞恩湖，卡贝尔桥，老镇，狮子纪念碑。</div>
					</div>
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/hotel/Hotel Ramada Hotel Innsbruck/Hotel Innsbruck_dining.jpg" />
							</div>
							<div class="hotelIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">Hotel Ramada Hotel Innsbruck因斯布鲁克酒店</div>
							</div>
						</div>
						<div class="hotelDes">酒店因斯布鲁克酒店因斯布鲁克市中心，步行即可到达所有景点和地标。</div>
					</div>
					<div class="swiper-slide">
						<div class="swiperBgWrap">
							<div class="slideBg">
								<img src="img/hotel/Hotel Ramada Hotel Innsbruck/Hotel Innsbruck_room.jpg" />
							</div>
							<div class="hotelIntro">
								<div class="transparentBg"></div>
								<div class="transparentTxt">Hotel Ramada Hotel Innsbruck因斯布鲁克酒店</div>
							</div>
						</div>
						<div class="hotelDes">乘坐巴士5分钟可以到达因斯布鲁克市中心。</div>
					</div>
				</div>
				<!-- 如果需要分页器 -->
				<div class="swiper-pagination">
				</div>
			</div>
		</div>

		<!-- Flight -->
		<div class="site flight">
			<h4 class="flex-row-end-between">
				航班信息
				<div>
					<label>出发城市:</label>
					<select>
						<option>北京</option>
						<option>上海</option>
						<option>广州</option>
						<option>香港</option>
						<option>成都</option>
					</select>
				</div>
			</h4>
			<p class="notes">以下是参考航班信息，以最终实际预订情况为准。</p>
			<div class="swiper-container section">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<div class="departure">成都出发</div>
						<div class="autoWrapper">
							<div class="com_flightInfo">
								<div class="voyage">启程</div>
								<div class="ibWrap">
									<div class="">荷兰皇家航空</div>
									<div class="">13h50m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>成都</span>14:35</div>
									<div class="airport"><span>阿姆斯特丹</span>19:05</div>
									<div class="airport"><span>阿姆斯特丹</span>21:00</div>
									<div class="airport"><span>苏黎世</span>22:25</div>
								</div>
							</div>
							<div class="com_flightInfo">
								<div class="voyage">回程</div>
								<div class="ibWrap">
									<div class="">荷兰皇家航空</div>
									<div class="">13h0m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>慕尼黑</span>17:50</div>
									<div class="airport"><span>阿姆斯特丹</span>19:25</div>
									<div class="airport"><span>阿姆斯特丹</span>21:05</div>
									<div class="airport"><span>成都</span>12:50+1</div>
								</div>
							</div>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="departure">上海出发</div>
						<div class="autoWrapper">
							<div class="com_flightInfo">
								<div class="voyage">启程</div>
								<div class="ibWrap">
									<div class="">阿联酋航空</div>
									<div class="">19h5m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>上海</span>07:15</div>
									<div class="airport"><span>迪拜</span>12:05</div>
									<div class="airport"><span>迪拜</span>15:45</div>
									<div class="airport"><span>苏黎世</span>20:20</div>
								</div>
							</div>
							<div class="com_flightInfo">
								<div class="voyage">回程</div>
								<div class="ibWrap">
									<div class="">阿联酋航空</div>
									<div class="">17h45m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>慕尼黑</span>22:35</div>
									<div class="airport"><span>迪拜</span>06:30+1</div>
									<div class="airport"><span>迪拜</span>09:40</div>
									<div class="airport"><span>上海</span>22:20</div>
								</div>
							</div>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="departure">北京出发</div>
						<div class="autoWrapper">
							<div class="com_flightInfo">
								<div class="voyage">启程</div>
								<div class="ibWrap">
									<div class="">阿联酋航空</div>
									<div class="">18h55m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>北京</span>07:25</div>
									<div class="airport"><span>迪拜</span>11:35</div>
									<div class="airport"><span>迪拜</span>15:35</div>
									<div class="airport"><span>苏黎世</span>20:20</div>
								</div>
							</div>
							<div class="com_flightInfo">
								<div class="voyage">回程</div>
								<div class="ibWrap">
									<div class="">阿联酋航空</div>
									<div class="">17h45m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>慕尼黑</span>22:35</div>
									<div class="airport"><span>迪拜</span>06:30+1</div>
									<div class="airport"><span>迪拜</span>10:50</div>
									<div class="airport"><span>北京</span>22:20</div>
								</div>
							</div>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="departure">广州出发</div>
						<div class="autoWrapper">
							<div class="com_flightInfo">
								<div class="voyage">启程</div>
								<div class="ibWrap">
									<div class="">南方航空</div>
									<div class="">荷兰航空</div>
									<div class="">17h0m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>广州</span>00:05</div>
									<div class="airport"><span>阿姆斯特丹</span>06:45</div>
									<div class="airport"><span>阿姆斯特丹</span>09:35</div>
									<div class="airport"><span>苏黎世</span>11:05</div>
								</div>
							</div>
							<div class="com_flightInfo">
								<div class="voyage">回程</div>
								<div class="ibWrap">
									<div class="">法国航空</div>
									<div class="">南方航空</div>
									<div class="">16h45m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>慕尼黑</span>07:15</div>
									<div class="airport"><span>巴黎</span>08:55</div>
									<div class="airport"><span>巴黎</span>12:25</div>
									<div class="airport"><span>广州</span>06:00+1</div>
								</div>
							</div>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="departure">香港出发</div>
						<div class="autoWrapper">
							<div class="com_flightInfo">
								<div class="voyage">启程</div>
								<div class="ibWrap">
									<div class="">阿提哈德航空</div>
									<div class="">18h0m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>香港</span>18:55</div>
									<div class="airport"><span>阿布扎比</span>23:40</div>
									<div class="airport"><span>阿布扎比</span>02:20</div>
									<div class="airport"><span>苏黎世</span>06:55</div>
								</div>
							</div>
							<div class="com_flightInfo">
								<div class="voyage">回程</div>
								<div class="ibWrap">
									<div class="">阿提哈德航空</div>
									<div class="">15h55m</div>
									<div class="">1次中转</div>
								</div>
								<div class="flex-row-start-between">
									<div class="airport"><span>慕尼黑</span>12:10</div>
									<div class="airport"><span>阿布扎比</span>20:25</div>
									<div class="airport"><span>阿布扎比</span>21:50</div>
									<div class="airport"><span>香港</span>10:05+1</div>
								</div>
							</div>
						</div>
					</div>

				</div>
				<!-- 如果需要分页器 -->
				<div class="swiper-pagination">
				</div>
			</div>
		</div>
		<!-- Reviews -->
		<div class="site reviews">
			<h4>来自客户的评价</h4>
			<div class="swiper-container section">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<div class="com_dialog">
							<div class="dialogWrap">
								<div class="rate">
									<i class="fa fa-star active" aria-hidden="true"></i>
									<i class="fa fa-star active" aria-hidden="true"></i>
									<i class="fa fa-star active" aria-hidden="true"></i>
									<i class="fa fa-star active" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</div>
								<div class="dialog">
									第一次在国外过圣诞节和跨年，阿姆斯特丹真是个神奇的城市，既充满文艺气息，又有如此光怪陆离的一面；三个城市中间，个人更喜欢伦敦，以及伦敦人的伦敦腔，伦敦当地的local guide也超级可爱幽默，圣诞节当天还给我们准备了Mince Pie；有机会想再去待久一些，最想感谢一起旅行的小伙伴们，一起跨年的经历实在太难忘。
								</div>
								<div class="dialogBelongTo"></div>
							</div>
						</div>
						<div class="userInfo">
							<span class="name">Jax Oddo,</span>
							<span class="position">外籍导游</span>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiper-slide">
							<div class="com_dialog grayBlue">
								<div class="dialogWrap">
									<div class="rate">
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</div>
									<div class="dialog">
										第一次在国外过圣诞节和跨年，阿姆斯特丹真是个神奇的城市，既充满文艺气息，又有如此光怪陆离的一面；三个城市中间，个人更喜欢伦敦，以及伦敦人的伦敦腔，伦敦当地的local guide也超级可爱幽默，圣诞节当天还给我们准备了Mince Pie；有机会想再去待久一些，最想感谢一起旅行的小伙伴们，一起跨年的经历实在太难忘。
									</div>
									<div class="dialogBelongTo"></div>
								</div>
							</div>
							<div class="userInfo">
								<span class="name">Jax Oddo,</span>
								<span class="position">外籍导游</span>
							</div>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiper-slide">
							<div class="com_dialog">
								<div class="dialogWrap">
									<div class="rate">
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</div>
									<div class="dialog">
										第一次在国外过圣诞节和跨年，阿姆斯特丹真是个神奇的城市，既充满文艺气息，又有如此光怪陆离的一面；三个城市中间，个人更喜欢伦敦，以及伦敦人的伦敦腔，伦敦当地的local guide也超级可爱幽默，圣诞节当天还给我们准备了Mince Pie；有机会想再去待久一些，最想感谢一起旅行的小伙伴们，一起跨年的经历实在太难忘。
									</div>
								</div>
								<div class="dialogBelongTo"></div>
							</div>
							<div class="userInfo">
								<span class="name">Jax Oddo,</span>
								<span class="position">外籍导游</span>
							</div>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiper-slide">
							<div class="com_dialog grayBlue">
								<div class="dialogWrap">
									<div class="rate">
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</div>
									<div class="dialog">
										第一次在国外过圣诞节和跨年，阿姆斯特丹真是个神奇的城市，既充满文艺气息，又有如此光怪陆离的一面；三个城市中间，个人更喜欢伦敦，以及伦敦人的伦敦腔，伦敦当地的local guide也超级可爱幽默，圣诞节当天还给我们准备了Mince Pie；有机会想再去待久一些，最想感谢一起旅行的小伙伴们，一起跨年的经历实在太难忘。
									</div>
									<div class="dialogBelongTo"></div>
								</div>
							</div>
							<div class="userInfo">
								<span class="name">Jax Oddo,</span>
								<span class="position">外籍导游</span>
							</div>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiper-slide">
							<div class="com_dialog">
								<div class="dialogWrap">
									<div class="rate">
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</div>
									<div class="dialog">
										第一次在国外过圣诞节和跨年，阿姆斯特丹真是个神奇的城市，既充满文艺气息，又有如此光怪陆离的一面；三个城市中间，个人更喜欢伦敦，以及伦敦人的伦敦腔，伦敦当地的local guide也超级可爱幽默，圣诞节当天还给我们准备了Mince Pie；有机会想再去待久一些，最想感谢一起旅行的小伙伴们，一起跨年的经历实在太难忘。
									</div>
									<div class="dialogBelongTo"></div>
								</div>
							</div>
							<div class="userInfo">
								<span class="name">Jax Oddo,</span>
								<span class="position">外籍导游</span>
							</div>
						</div>
					</div>
					<div class="swiper-slide">
						<div class="swiper-slide">
							<div class="com_dialog grayBlue">
								<div class="dialogWrap">
									<div class="rate">
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star active" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</div>
									<div class="dialog">
										第一次在国外过圣诞节和跨年，阿姆斯特丹真是个神奇的城市，既充满文艺气息，又有如此光怪陆离的一面；三个城市中间，个人更喜欢伦敦，以及伦敦人的伦敦腔，伦敦当地的local guide也超级可爱幽默，圣诞节当天还给我们准备了Mince Pie；有机会想再去待久一些，最想感谢一起旅行的小伙伴们，一起跨年的经历实在太难忘。
									</div>
								</div>
								<div class="dialogBelongTo"></div>
							</div>
							<div class="userInfo">
								<span class="name">Jax Oddo,</span>
								<span class="position">外籍导游</span>
							</div>
						</div>
					</div>
				</div>
				<!-- 如果需要分页器 -->
				<div class="swiper-pagination">
				</div>
			</div>
		</div>

		<!-- Get a personalized quotation -->
		<div class="section quoBg" name="getPersonalizedPrice" id="getPersonalizedPrice">

			<div class="quotation">

				<h4>获取实时价格</h4>

				<div class="quotationBg"></div>

				<div class="quotationWrap">

					<?php include_once('quotation-form.php') ;?>

				</div>

				<?php include_once('sales-wrap.php') ;?>

			</div>

		</div>
		<!-- More trips like this -->
		<div class="site">
			<!-- trips -->
			<?php include_once('recommend.php') ;?>
		</div>
		<!-- From the blog -->
		<div class="site blog">
			<h4 class="flex-row-end-between">
				博客
				<a href="http://travelplus.ef.com.cn/blog/" class="blueBorderBtn">全部</a>
			</h4>
			<div class="flex-row-start-around flex-flow">
				<div class="flex1 flex-row-center-between">
					<div class="image">
						<img src="http://travelplus.ef.com.cn/blog/wp-content/uploads/2017/03/cover-352x230.jpg" />
					</div>
					<div class="info">
						<h5>Humanities Blog – EF TravelPlus Barcelona</h5>
						<time>02-27-2017</time>
					</div>
				</div>
				<div class="flex1 flex-row-center-between">
					<div class="image">
						<img src="http://travelplus.ef.com.cn/blog/wp-content/uploads/2017/03/cover-352x230.jpg" />
					</div>
					<div class="info">
						<h5>Humanities Blog – EF TravelPlus Barcelona</h5>
						<time>02-27-2017</time>
					</div>
				</div>
				<div class="flex1 flex-row-center-between">
					<div class="image">
						<img src="http://travelplus.ef.com.cn/blog/wp-content/uploads/2017/03/cover-352x230.jpg" />
					</div>
					<div class="info">
						<h5>Humanities Blog – EF TravelPlus Barcelona</h5>
						<time>02-27-2017</time>
					</div>
				</div>
			</div>
		</div>
		<!-- footer -->
		<?php include_once('common-footer.php') ;?>
		<?php include_once('popup.php') ;?>
		<script src="js/jquery-2.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/sticky.min.js"></script>
		<script src="js/itinerary.js"></script>
	</body>

</html>