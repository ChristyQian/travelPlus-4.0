<div class="discount">

	<div class="transparentBg"></div>

	<div class="transparentTxt">
		<span>限国庆出发</span>

		<p>2人同行<br/>1人半价</p>

		6月30日前

	</div>

</div>