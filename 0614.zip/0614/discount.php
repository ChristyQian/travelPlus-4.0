<div class="discount">

	<div class="transparentBg"></div>

	<div class="transparentTxt">

		<p>节省5%</p>

		6月30日<br /> 之前预定

	</div>

</div>