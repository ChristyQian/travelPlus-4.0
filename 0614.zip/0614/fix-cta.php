<div class="fixCAT">
			<div class="site">
				<div class="com_dialog">
					<div class="dialogWrap">
						<i class="closeIcon">&times;</i>
						<div class="dialog">
							<div class="flex-row-center-start">
								<div class="wechatImg">
									<img src="img/sSqrcode.jpg" width="80" height="80" />
								</div>
								<div class="flexAuto">
									<p>
										有问题要问？<br />
										不如一键添加旅游顾问：EF小家<br/>
										他能解答你的任何问题
									</p>
								</div>
							</div>
						</div>
						<div class="dialogBelongTo"></div>
					</div>
				</div>
				<div class="flex-row-center-between">
			        <div id="sticky-wechat" class="flex-row-center-start"><div class="icon Oval-5"><i class="fa fa-wechat"></i></div>微信咨询</div>
			        	<div class="flex-row-center-end">
				        	<div class="hotline flex-row-center-end">
				        		<div  id="sticky-hotline" class="flex-no-grow-no-shrink-auto icon Oval"><a class="call" href="tel:400-180-7518" onclick="s_objectID=&quot;tel:400-180-7518_2&quot;;return this.s_oc?this.s_oc(e):true"></a></div>
				        		<div class="flex-no-grow-no-shrink-auto">
					        		<p>来电咨询</p>
					        		<span>400-180-7518</span>
				        		</div>
				        	</div>
				        	<a id="sticky-get-price" class="orangeBtn" href="#getPersonalizedPrice">
				        		获取价格
				        	</a> 
			        	</div>
		        </div>
			</div>
		</div>